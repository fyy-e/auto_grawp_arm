#include "dummy_robot.h"
#include <iostream>
/**
 * @brief 计算6个关节角度差值的绝对值最大值
 * @param _joints 关节角度差值数组
 * @param _index 输出：最大值对应的关节索引（0~5）
 * @return 绝对值最大值
 */
inline float AbsMaxOf6(DOF6Kinematic::Joint6D_t _joints, uint8_t &_index)
{
    float max = -1;
    for (uint8_t i = 0; i < 6; i++)
    {
        if (abs(_joints.a[i]) > max)
        {
            max = abs(_joints.a[i]);
            _index = i;
        }
    }
    return max;
}

/**
 * @brief DummyRobot构造函数
 * 初始化关节电机、机械手、运动学解算器
 * @param _hcan CAN总线句柄
 */
DummyRobot::DummyRobot(SocketCan* _hcan) :
    hcan(_hcan)
{
    // 初始化关节电机控制器（索引0=所有关节，1~6=对应关节）
    // 参数：CAN句柄、节点ID、方向反转、减速比、最小角度限制、最大角度限制
    motorJ[ALL] = new CtrlStepMotor(_hcan, 0, false, 15, -180, 180);
    motorJ[1] = new CtrlStepMotor(_hcan, 1, true, 15, -180, 180);
    motorJ[2] = new CtrlStepMotor(_hcan, 2, false, 15, -90, 90);
    motorJ[3] = new CtrlStepMotor(_hcan, 3, true, 15, -180, 180);
    motorJ[4] = new CtrlStepMotor(_hcan, 4, false, 15, -90, 90);
    motorJ[5] = new CtrlStepMotor(_hcan, 5, true, 15, -180, 180);
    motorJ[6] = new CtrlStepMotor(_hcan, 6, true, 15, -720, 720);
    hand = new DummyHand(_hcan, 7); // 初始化机械手

    // 初始化6自由度运动学解算器（参数为机械臂连杆长度，单位m）
    dof6Solver = new DOF6Kinematic(0.109f, 0.035f, 0.146f, 0.115f, 0.052f, 0.072f);
}

/**
 * @brief DummyRobot析构函数
 * 释放所有动态分配的资源
 */
DummyRobot::~DummyRobot()
{
    // 释放关节电机控制器
    for (int j = 0; j <= 6; j++)
        delete motorJ[j];
    // 释放机械手和运动学解算器
    delete hand;
    delete dof6Solver;
}

/**
 * @brief 机械臂初始化
 * 设置默认指令模式和默认关节速度
 */
void DummyRobot::Init()
{
    SetCommandMode(DEFAULT_COMMAND_MODE);
    SetJointSpeed(DEFAULT_JOINT_SPEED);
}

/**
 * @brief 机械臂重启
 * 先重启所有关节电机，延时等待后复位系统
 */
void DummyRobot::Reboot()
{
    for(int i = 1;i <= 6;i++){
        motorJ[i]->Reboot();
    }
    // motorJ[ALL]->Reboot();
    osDelay(500); // 等待所有关节完成重启
}

/**
 * @brief 驱动关节运动到目标角度
 * 计算目标角度与初始姿态的差值，带速度限制设置
 * @param _joints 目标关节角度
 */
void DummyRobot::MoveJoints(DOF6Kinematic::Joint6D_t _joints)
{
    for (int j = 1; j <= 6; j++)
    {
        // 设置关节目标角度（减去初始姿态偏移），并应用动态速度限制
        std::cout << "关节："  << j << "角度："<<_joints.a[j - 1] << "角度："<<initPose.a[j - 1] << std::endl;
        motorJ[j]->SetAngleWithVelocityLimit(_joints.a[j - 1] - initPose.a[j - 1],
                                             dynamicJointSpeeds.a[j - 1]);
    }
}

/**
 * @brief 关节空间运动指令实现
 * 1. 检查目标角度是否在限位范围内
 * 2. 计算关节角度差值，规划各关节运动速度
 * 3. 更新目标关节角度和运动状态标志
 * @param _j1~_j6 关节1~6目标角度
 * @return true=角度合法，false=角度超限
 */
bool DummyRobot::MoveJ(float _j1, float _j2, float _j3, float _j4, float _j5, float _j6)
{
    DOF6Kinematic::Joint6D_t targetJointsTmp(_j1, _j2, _j3, _j4, _j5, _j6);
    bool valid = true;

    // 检查每个关节角度是否在限位范围内
    for (int j = 1; j <= 6; j++)
    {
        if (targetJointsTmp.a[j - 1] > motorJ[j]->angleLimitMax ||
            targetJointsTmp.a[j - 1] < motorJ[j]->angleLimitMin)
            valid = false;
    }

    if (valid)
    {
        // 计算当前关节与目标关节的差值
        DOF6Kinematic::Joint6D_t deltaJoints = targetJointsTmp - currentJoints;
        uint8_t index =0;
        // 找到差值最大的关节（用于计算运动时间）
        float maxAngle = AbsMaxOf6(deltaJoints, index);
        // 计算运动总时间：最大角度 / 关节速度 * 减速比
        float time = maxAngle * (float) (motorJ[index + 1]->reduction) / jointSpeed;
        
        // 计算各关节动态速度（保证所有关节同时到达目标）
        for (int j = 1; j <= 6; j++)
        {
            dynamicJointSpeeds.a[j - 1] =
                abs(deltaJoints.a[j - 1] * (float) (motorJ[j]->reduction) / time * 0.1f); // 转换为0~10r/s
        }

        jointsStateFlag = 0;    // 重置运动状态标志
        targetJoints = targetJointsTmp; // 更新目标关节角度
        return true;
    }
    return false;
}

/**
 * @brief 笛卡尔空间运动指令实现
 * 1. 逆运动学解算得到8组关节解
 * 2. 筛选出在限位范围内的有效解
 * 3. 选择与当前姿态最接近的解，调用MoveJ执行
 * @param _x/_y/_z 末端位置 (mm)
 * @param _a/_b/_c 末端姿态 (°)
 * @return true=有有效解，false=无解或角度超限
 */
bool DummyRobot::MoveL(float _x, float _y, float _z, float _a, float _b, float _c)
{
    DOF6Kinematic::Pose6D_t pose6D(_x, _y, _z, _a, _b, _c);
    DOF6Kinematic::IKSolves_t ikSolves{};       // 逆解结果（8组）
    DOF6Kinematic::Joint6D_t lastJoint6D{};      // 临时关节角度存储

    // 逆运动学解算
    dof6Solver->SolveIK(pose6D, lastJoint6D, ikSolves);

    bool valid[8];    // 8组解的有效性标志
    int validCnt = 0; // 有效解数量

    // 筛选有效解（所有关节角度在限位范围内）
    for (int i = 0; i < 8; i++)
    {
        valid[i] = true;
        for (int j = 1; j <= 6; j++)
        {
            if (ikSolves.config[i].a[j - 1] > motorJ[j]->angleLimitMax ||
                ikSolves.config[i].a[j - 1] < motorJ[j]->angleLimitMin)
            {
                valid[i] = false;
                continue;
            }
        }
        if (valid[i]) validCnt++;
    }

    if (validCnt)
    {
        float min = 1000;
        uint8_t indexConfig = 0, indexJoint = 0;
        // 选择与当前姿态最接近的有效解
        for (int i = 0; i < 8; i++)
        {
            if (valid[i])
            {
                for (int j = 0; j < 6; j++)
                    lastJoint6D.a[j] = ikSolves.config[i].a[j];
                // 计算与当前关节的差值
                DOF6Kinematic::Joint6D_t tmp = currentJoints - lastJoint6D;
                float maxAngle = AbsMaxOf6(tmp, indexJoint);
                // 记录最小差值的解
                if (maxAngle < min)
                {
                    min = maxAngle;
                    indexConfig = i;
                }
            }
        }
        // 调用MoveJ执行选中的解
        return MoveJ(ikSolves.config[indexConfig].a[0], ikSolves.config[indexConfig].a[1],
                     ikSolves.config[indexConfig].a[2], ikSolves.config[indexConfig].a[3],
                     ikSolves.config[indexConfig].a[4], ikSolves.config[indexConfig].a[5]);
    }
    return false;
}

/**
 * @brief 更新所有关节角度
 * 调用电机控制器的角度更新接口
 */
void DummyRobot::UpdateJointAngles()
{
    for(int i = 1;i <= 6;i++){
        motorJ[i]->UpdateAngle();
    }
    // motorJ[ALL]->UpdateAngle();
}

/**
 * @brief 关节角度更新回调
 * 1. 读取每个关节的当前角度，加上初始姿态偏移
 * 2. 更新关节运动状态标志（到位=1，未到位=0）
 */
void DummyRobot::UpdateJointAnglesCallback()
{
    for (int i = 1; i <= 6; i++)
    {
        // 更新当前关节角度（电机角度 + 初始姿态偏移）
        currentJoints.a[i - 1] = motorJ[i]->angle + initPose.a[i - 1];

        // 更新运动状态标志：bit1~bit6对应关节1~6
        if (motorJ[i]->state == CtrlStepMotor::FINISH)
            jointsStateFlag |= (1 << i);  // 关节到位，置1
        else
            jointsStateFlag &= ~(1 << i); // 关节未到位，置0
    }
}

/**
 * @brief 设置关节运动速度
 * 限制速度范围0~100，更新基础速度（乘以缩放系数）
 * @param _speed 速度百分比 (0~100)
 */
void DummyRobot::SetJointSpeed(float _speed)
{
    if (_speed < 0)_speed = 0;
    else if (_speed > 100) _speed = 100;
    jointSpeed = _speed / 100 * jointSpeedRatio * 1140;
}

/**
 * @brief 设置关节加速度
 * 限制加速度范围0~100，按基准值缩放后设置到电机
 * @param _acc 加速度百分比 (0~100)
 */
void DummyRobot::SetJointAcceleration(float _acc)
{
    if (_acc < 0)_acc = 0;
    else if (_acc > 100) _acc = 100;

    for (int i = 1; i <= 6; i++)
        // 实际加速度 = 百分比/100 * 对应关节基准加速度
        motorJ[i]->SetAcceleration(_acc / 100 * DEFAULT_JOINT_ACCELERATION_BASES.a[i - 1]);
}

/**
 * @brief 校准零点偏移
 * 步骤：
 * 1. 禁用自动更新，使能电机
 * 2. 降低关节2/3电流，手动校准到L姿态
 * 3. 首次应用零点偏移
 * 4. 移动到休息姿态，二次应用零点偏移
 * 5. 恢复电流限制，重启系统
 */
void DummyRobot::CalibrateHomeOffset()
{
    // 禁用自动更新，但保持电机使能（手动校准）
    isEnabled = false;
    for(int i = 1;i <=6;i++){
    motorJ[i]->SetEnable(true);
    }


    // 降低关节2/3电流，方便手动移动
    motorJ[2]->SetCurrentLimit(0.5);
    motorJ[3]->SetCurrentLimit(0.5);
    osDelay(500);

    // 首次应用零点偏移（将当前位置设为零点）
    for(int i = 1;i <=6;i++){
    motorJ[i]->ApplyPositionAsHome();
    }
    // motorJ[ALL]->ApplyPositionAsHome();
    osDelay(500);

    // 移动到休息姿态（临时初始姿态）
    initPose = DOF6Kinematic::Joint6D_t(0, 0, 90, 0, 0, 0);
    currentJoints = DOF6Kinematic::Joint6D_t(0, 0, 90, 0, 0, 0);
    Resting();
    osDelay(500);

    // 二次应用零点偏移
    for(int i = 1;i <=6;i++){
    motorJ[i]->ApplyPositionAsHome();
    }
    // motorJ[ALL]->ApplyPositionAsHome();
    osDelay(500);
    // 恢复关节2/3电流限制
    motorJ[2]->SetCurrentLimit(1);
    motorJ[3]->SetCurrentLimit(1);
    osDelay(500);

    Reboot(); // 重启生效
}

/**
 * @brief 回零操作
 * 低速移动到零位姿态 {0,0,90,0,0,0}，完成后恢复原速度
 */
void DummyRobot::Homing()
{
    float lastSpeed = jointSpeed; // 保存当前速度
    SetJointSpeed(10);            // 设置低速回零

    MoveJ(0, 45, 45, 0, 45, 0);    // 零位姿态
    MoveJoints(targetJoints);     // 驱动关节运动
    while (IsMoving())            // 等待运动完成
        osDelay(10);
    SetJointSpeed(lastSpeed);     // 恢复原速度
}

/**
 * @brief 回到休息姿态
 * 低速移动到REST_POSE，完成后恢复原速度
 */
void DummyRobot::Resting()
{
    float lastSpeed = jointSpeed; // 保存当前速度
    SetJointSpeed(10);            // 设置低速

    // 移动到休息姿态
    MoveJ(REST_POSE.a[0], REST_POSE.a[1], REST_POSE.a[2],
          REST_POSE.a[3], REST_POSE.a[4], REST_POSE.a[5]);
    MoveJoints(targetJoints);     // 驱动关节运动
    while (IsMoving())            // 等待运动完成
        osDelay(10);

    SetJointSpeed(lastSpeed);     // 恢复原速度
}

/**
 * @brief 设置机械臂使能状态
 * @param _enable true=使能所有关节电机，false=禁用
 */
void DummyRobot::SetEnable(bool _enable)
{
    for(int i = 1;i <=6;i++){
    motorJ[i]->SetEnable(_enable);
    }
    // motorJ[ALL]->SetEnable(_enable);
    isEnabled = _enable;
}

/**
 * @brief 更新末端笛卡尔位姿
 * 正运动学解算当前关节角度，转换单位（m→mm）
 */
void DummyRobot::UpdateJointPose6D()
{
    dof6Solver->SolveFK(currentJoints, currentPose6D); // 正解
    currentPose6D.X *= 1000; // 米转毫米
    currentPose6D.Y *= 1000;
    currentPose6D.Z *= 1000;
}

/**
 * @brief 判断机械臂是否运动中
 * 关节状态标志 != 0b1111110 表示有未到位的关节
 * (bit1~bit6=1 表示所有关节到位)
 * @return true=运动中，false=已到位
 */
bool DummyRobot::IsMoving()
{
    return jointsStateFlag != 0b1111110;
}

/**
 * @brief 判断机械臂是否使能
 * @return true=已使能，false=未使能
 */
bool DummyRobot::IsEnabled()
{
    return isEnabled;
}

/**
 * @brief 设置指令模式
 * 不同模式配置不同的速度缩放系数和加速度
 * @param _mode 指令模式（COMMAND_MODE枚举值）
 */
void DummyRobot::SetCommandMode(uint32_t _mode)
{
    // 校验模式范围
    if (_mode < COMMAND_TARGET_POINT_SEQUENTIAL ||
        _mode > COMMAND_CONTINUES_TRAJECTORY)
        return;

    commandMode = static_cast<CommandMode>(_mode);

    // 根据模式配置速度和加速度
    switch (commandMode)
    {
        case COMMAND_TARGET_POINT_SEQUENTIAL:
        case COMMAND_TARGET_POINT_INTERRUPTABLE:
            jointSpeedRatio = 1; // 速度缩放100%
            SetJointAcceleration(DEFAULT_JOINT_ACCELERATION_LOW); // 低加速度
            break;
        case COMMAND_CONTINUES_TRAJECTORY:
            SetJointAcceleration(DEFAULT_JOINT_ACCELERATION_HIGH); // 高加速度
            jointSpeedRatio = 0.3; // 速度缩放30%
            break;
    }
}

/**
 * @brief DummyHand构造函数
 * 初始化CAN发送头、节点ID、CAN句柄
 * @param _hcan CAN总线句柄
 * @param _id 机械手CAN节点ID
 */
DummyHand::DummyHand(SocketCan* _hcan, uint8_t _id) :
    nodeID(_id), hcan(_hcan)
{
}

/**
 * @brief 设置机械手目标角度
 * 限制角度范围0~30°，通过CAN发送角度指令
 * @param _angle 目标角度 (°)
 */
void DummyHand::SetAngle(float _angle)
{
}

/**
 * @brief 设置机械手最大电流
 * 限制电流范围0~1A，通过CAN发送电流指令
 * @param _val 电流值 (A)
 */
void DummyHand::SetMaxCurrent(float _val)
{
}

/**
 * @brief 设置机械手使能状态
 * 使能=设置为最大电流，禁用=设置为0电流
 * @param _enable true=使能，false=禁用
 */
void DummyHand::SetEnable(bool _enable)
{

}
