// main.cpp
#include <iostream>
#include <thread>
#include <chrono>
#include <atomic>
#include "dummy_robot.h"
#include "socketcan.h"

// 全局变量
std::atomic<bool> g_thread_running(true);
// SocketCan g_hcan;  // 假设已经初始化好的CAN总线对象

/**
 * @brief 角度更新线程函数
 * 以固定频率更新关节角度和状态
 */
void UpdateThread(DummyRobot* robot, int update_rate_hz) {
    using namespace std::chrono;
    
    int update_period_ms = 1000 / update_rate_hz;
    auto next_time = steady_clock::now();
    
    while (g_thread_running) {
        // 更新关节角度
        robot->UpdateJointAngles();
        
        // 更新角度回调（处理状态标志）
        robot->UpdateJointAnglesCallback();
        
        // 更新末端位姿（可选）
        // robot->UpdateJointPose6D();
        
        // 固定频率执行
        next_time += milliseconds(update_period_ms);
        std::this_thread::sleep_until(next_time);
    }
}

/**
 * @brief 打印当前关节角度
 */
void PrintJointAngles(const DummyRobot& robot) {
    std::cout << "当前关节角度: ";
    for (int i = 0; i < 6; i++) {
        std::cout << "J" << i+1 << "=" << robot.currentJoints.a[i] << "° ";
    }
    std::cout << std::endl;
}

/**
 * @brief 打印末端位姿
 */
void PrintPose(const DummyRobot& robot) {
    std::cout << "末端位姿: X=" << robot.currentPose6D.X << "mm "
              << "Y=" << robot.currentPose6D.Y << "mm "
              << "Z=" << robot.currentPose6D.Z << "mm "
              << "A=" << robot.currentPose6D.A << "° "
              << "B=" << robot.currentPose6D.B << "° "
              << "C=" << robot.currentPose6D.C << "°"
              << std::endl;
}

int main() {
    std::cout << "===== 机械臂控制系统测试 =====" << std::endl;
    
    // 1. 创建机械臂对象
        // 2. 初始化 CAN 总线
    SocketCan can_bus;
    if (!can_bus.open("can0")) {
        std::cerr << "CAN 总线初始化失败！" << std::endl;
        return EXIT_FAILURE;
    } else {
        std::cout << "CAN 总线初始化完成！" << std::endl;  
    }
    DummyRobot robot(&can_bus);
    
    // 2. 初始化机械臂
    std::cout << "初始化机械臂..." << std::endl;
    robot.Init();
    robot.SetEnable(true);
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    
    // 3. 启动角度更新线程
    std::cout << "启动角度更新线程 (100Hz)..." << std::endl;
    std::thread update_thread(UpdateThread, &robot, 100);
    
    // 4. 等待机械臂使能完成
    std::this_thread::sleep_for(std::chrono::milliseconds(500));
    // robot.Resting();
    // while(robot.IsMoving()){
    //     osDelay(20);
    // }
    robot.Homing();
    std::this_thread::sleep_for(std::chrono::milliseconds(2000));
    std::cout << "开始resting()!!!!!!!!!!!!" << std::endl;
    robot.Resting();
    try {
        while(1){
        PrintJointAngles(robot);
        osDelay(100);
        }
        // // 5. 测试1: 关节空间运动
        // std::cout << "\n测试1: 关节空间运动 (MoveJ)..." << std::endl;
        // PrintJointAngles(robot);
        
        // // 移动到目标位置
        // bool move_success = robot.MoveJ(0, 0, 60, 0, 0, 0);
        // if (move_success) {
        //     std::cout << "运动指令已下发" << std::endl;
            
        //     // 驱动关节运动
        //     robot.MoveJoints(robot.targetJoints);
            
        //     // 等待运动完成
        //     while (robot.IsMoving()) {
        //         std::cout << "运动中..." << std::endl;
        //         PrintJointAngles(robot);
        //         std::this_thread::sleep_for(std::chrono::milliseconds(100));
        //     }
        //     std::cout << "运动完成!" << std::endl;
        //     PrintJointAngles(robot);
        // } else {
        //     std::cout << "运动指令非法!" << std::endl;
        // }
        
        // // 6. 测试2: 笛卡尔空间运动
        // std::cout << "\n测试2: 笛卡尔空间运动 (MoveL)..." << std::endl;
        // PrintPose(robot);
        
        // // 计算当前位置上方100mm的点
        // float target_x = robot.currentPose6D.X;
        // float target_y = robot.currentPose6D.Y;
        // float target_z = robot.currentPose6D.Z + 100;  // Z+100mm
        
        // move_success = robot.MoveL(target_x, target_y, target_z, 
        //                            robot.currentPose6D.A, 
        //                            robot.currentPose6D.B, 
        //                            robot.currentPose6D.C);
        
        // if (move_success) {
        //     std::cout << "向Z+100mm移动" << std::endl;
        //     robot.MoveJoints(robot.targetJoints);
            
        //     // 等待运动完成
        //     while (robot.IsMoving()) {
        //         std::cout << "运动中..." << std::endl;
        //         PrintPose(robot);
        //         std::this_thread::sleep_for(std::chrono::milliseconds(100));
        //     }
        //     std::cout << "运动完成!" << std::endl;
        //     PrintPose(robot);
        // } else {
        //     std::cout << "逆运动学无解!" << std::endl;
        // }
        
        // // 7. 测试3: 回到休息姿态
        // std::cout << "\n测试3: 回到休息姿态..." << std::endl;
        // robot.Resting();
        
        // while (robot.IsMoving()) {
        //     std::this_thread::sleep_for(std::chrono::milliseconds(100));
        // }
        // std::cout << "已回到休息姿态" << std::endl;
        
        // // 8. 测试4: 速度设置
        // std::cout << "\n测试4: 调整关节速度..." << std::endl;
        // robot.SetJointSpeed(50);  // 50%速度
        // std::cout << "关节速度已设置为50%" << std::endl;
        
        // // 9. 测试5: 指令模式切换
        // std::cout << "\n测试5: 切换指令模式..." << std::endl;
        // robot.SetCommandMode(DummyRobot::COMMAND_CONTINUES_TRAJECTORY);
        // std::cout << "已切换到连续轨迹模式" << std::endl;
        
    } catch (const std::exception& e) {
        std::cerr << "测试过程中发生异常: " << e.what() << std::endl;
    }
    
    // 10. 清理
    std::cout << "\n清理资源..." << std::endl;
    g_thread_running = false;
    if (update_thread.joinable()) {
        update_thread.join();
    }
    
    robot.SetEnable(false);
    
    std::cout << "测试完成!" << std::endl;
    
    return 0;
}