#include "ctrl_step.h"
#include "iostream"

float degreesToRadians(float degrees) {
    return degrees * M_PI / 180.0f;
}

/**
 * @brief 角度单位转换：弧度 -> 度
 */
float radiansToDegrees(float radians) {
    return radians * 180.0f / M_PI;
}
CtrlStepMotor::CtrlStepMotor(SocketCan* _hcan, size_t _id, bool _inverse,
                             uint8_t _reduction, float _angleLimitMin, float _angleLimitMax) :
    hcan(_hcan)
{
    nodeID = _id;
    angleLimitMax = _angleLimitMax;
    angleLimitMin = _angleLimitMin;
    inverseDirection = _inverse;
    // reduction = _reduction;
    motor = MotorController(_hcan,nodeID);
}


void CtrlStepMotor::SetEnable(bool _enable)
{
    state = _enable ? FINISH : STOP;
    motor.feed();  // 发送心跳
    if (_enable) {
        // 启用电机：设置为位置模式
        motor.set_mode(MODE_POSITION);
    } else {
        // 禁用电机：设置为空闲模式
        motor.set_mode(MODE_IDLE);
    }
}
void CtrlStepMotor::SetCurrentSetPoint(float _val)
{
    state = RUNNING;
    
    // 转换为扭矩设定值（假设单位转换）
    float torque = _val * 0.1f;  // 比例系数需要根据实际电机调整
    motor.write_torque_target(torque);
    // 切换为扭矩模式
    motor.set_mode(MODE_TORQUE);
}


void CtrlStepMotor::SetVelocitySetPoint(float _val)
{
    state = RUNNING;
    // 转换单位：度/秒 -> 弧度/秒
    float stepMotorCnt = _val *(float)reduction;
    float velocity_rad = degreesToRadians(stepMotorCnt);
    motor.set_target_velocity(velocity_rad);
    // 切换为速度模式
    motor.set_mode(MODE_VELOCITY);

    motor.write_pdo_2();
    osDelay(2);
}


void CtrlStepMotor::SetPositionSetPoint(float _val)
{
    // 检查角度限位
    if (_val > angleLimitMax) _val = angleLimitMax;
    if (_val < angleLimitMin) _val = angleLimitMin;
    
    float stepMotorCnt = _val * (float)reduction;
    // 转换为弧度：步进电机计数 -> 弧度
    float position_rad = degreesToRadians(stepMotorCnt);
    
    // 设置目标位置
    motor.write_position_target(position_rad);
    // 更新状态
    state = RUNNING;
}


void CtrlStepMotor::SetPositionWithVelocityLimit(float _pos, float _vel)
{
    // 检查角度限位
    if (_pos > angleLimitMax) _pos = angleLimitMax;
    if (_pos < angleLimitMin) _pos = angleLimitMin;
    
    // 考虑减速比
    float stepMotorCnt = _pos *(float)reduction;
    float stepMotor_vel = _vel *(float)reduction;
    std::cout << "位置："<< stepMotorCnt << std::endl;
    std::cout << "速度：" <<stepMotor_vel << std::endl;
    std::cout << "reduction:" <<reduction << std::endl;
    // 转换为弧度
    float position_rad = degreesToRadians(stepMotorCnt);
    
    // 速度转换：度/秒 -> 弧度/秒
    float velocity_rad = degreesToRadians(stepMotor_vel);
    std::cout << "位置："<< position_rad << std::endl;
    std::cout << "速度：" <<velocity_rad << std::endl;
    motor.set_target_position(position_rad);
    motor.set_target_velocity(velocity_rad);
    
    // 发送PDO2控制指令
    motor.write_pdo_2();
    // 更新状态
    state = RUNNING;
}

void CtrlStepMotor::SetNodeID(uint32_t _id)
{
    std::cout << "电机ID不可随意更改" << std::endl;
}


void CtrlStepMotor::SetCurrentLimit(float _val)
{
    motor.write_current_limit(_val);
    std::cout << "Motor " << (int)nodeID << ": Current limit set to " << _val << " A" << std::endl;
}


void CtrlStepMotor::SetVelocityLimit(float _val)
{
    // 转换单位：度/秒 -> 弧度/秒
    float velocity_rad = degreesToRadians(_val);
    motor.write_velocity_limit(velocity_rad);
    std::cout << "Motor " << (int)nodeID << ": Velocity limit set to " << _val << " deg/s" << std::endl;
}


void CtrlStepMotor::SetAcceleration(float _val)
{
    std::cout<<"设置加速度功能未实现"<<std::endl;
    SetVelocityLimit(_val);
}


void CtrlStepMotor::ApplyPositionAsHome()
{
    // 读取当前位置
    float current_pos = motor.read_position_measured();
    // 设置位置偏移
    motor.write_position_offset(-current_pos);
}


void CtrlStepMotor::SetEnableOnBoot(bool _enable)
{
        motor.ping();
        motor.feed();
        ApplyPositionAsHome();
        motor_mode = MODE_POSITION;
        motor.set_mode(motor_mode);  // 直接使用配置文件中的枚举，避免硬编码
        std::cout << "\n设置电机"<<nodeID<<"为:"<< motor_mode <<"模式"<< std::endl;
        osDelay(20);  // 等待模式切换完成（电机内部需要时间切换控制逻辑）
}


void CtrlStepMotor::SetEnableStallProtect(bool _enable)
{
    std::cout<<"失速保护未实现"<<std::endl;
}


void CtrlStepMotor::Reboot()
{
    std::cout << "Motor " << (int)nodeID << ": Reboot command sent" << std::endl;
    // 发送重启命令（需要MotorController支持）
    SetPositionWithVelocityLimit(0.0,0.0);
    osDelay(20);
    // motor.set_mode(MODE_IDLE);
    // // osDelay(100);  // 100ms延迟
    motor.set_mode(MODE_POSITION);    
}


void CtrlStepMotor::EraseConfigs()
{
        std::cout<<"不能擦除带电机配置"<<std::endl;
}


void CtrlStepMotor::SetAngle(float _angle)
{
    SetPositionSetPoint(_angle);
}


void CtrlStepMotor::SetAngleWithVelocityLimit(float _angle, float _vel) {
    SetPositionWithVelocityLimit(_angle, _vel);
}

void CtrlStepMotor::UpdateAngle()
{
    angle = radiansToDegrees(motor.read_position_measured() / (float)reduction);
    if(abs((motor.read_position_target() - degreesToRadians(angle))) <= 0.01){
        state = FINISH;
    }else{
        state = RUNNING;
    }
}


void CtrlStepMotor::UpdateAngleCallback(float _pos, bool _isFinished)
{
    state = _isFinished ? FINISH : RUNNING;
}


