#ifndef REF_STM32F4_FW_DUMMY_ROBOT_H
#define REF_STM32F4_FW_DUMMY_ROBOT_H

#include "algorithms/kinematic/6dof_kinematic.h"  // 6自由度运动学解算库
#include "ctrl_step/ctrl_step.h"       // 步进电机控制库

/**
 * @brief 表示所有关节的宏定义
 * 用于统一操作所有6个关节时的索引标识
 */
#define ALL 0

/**
 * 关节控制参数配置表
 * - current_limit: 关节电流限制 (A)
 * - acceleration: 关节加速度 (°/s²)
 * - dce_kp/dce_kv/dce_ki/dce_kd: 闭环控制PID参数
 */
/*
  |   PARAMS   | `current_limit` | `acceleration` | `dce_kp` | `dce_kv` | `dce_ki` | `dce_kd` |
  | ---------- | --------------- | -------------- | -------- | -------- | -------- | -------- |
  | **Joint1** | 2               | 30             | 1000     | 80       | 200      | 250      |
  | **Joint2** | 2               | 30             | 1000     | 80       | 200      | 200      |
  | **Joint3** | 2               | 30             | 1500     | 80       | 200      | 250      |
  | **Joint4** | 2               | 30             | 1000     | 80       | 200      | 250      |
  | **Joint5** | 2               | 30             | 1000     | 80       | 200      | 250      |
  | **Joint6** | 2               | 30             | 1000     | 80       | 200      | 250      |
 */

/**
 * @class DummyHand
 * @brief 机械手控制类
 * 负责机械手的CAN通信、角度设置、使能控制、电流限制配置
 */
class DummyHand
{
public:
    uint8_t nodeID = 7;          // 机械手CAN节点ID
    float maxCurrent = 0.7;      // 机械手最大电流限制 (A)

    /**
     * @brief 构造函数
     * @param _hcan CAN总线句柄
     * @param _id 机械手CAN节点ID
     */
    DummyHand(SocketCan* _hcan, uint8_t _id);

    /**
     * @brief 设置机械手目标角度
     * @param _angle 目标角度 (°)，范围0~45°
     */
    void SetAngle(float _angle);

    /**
     * @brief 设置机械手最大电流限制
     * @param _val 电流值 (A)，范围0~1A
     */
    void SetMaxCurrent(float _val);

    /**
     * @brief 设置机械手使能状态
     * @param _enable true=使能，false=禁用（禁用时电流设为0）
     */
    void SetEnable(bool _enable);
private:
    SocketCan* hcan;
    float minAngle = 0;              // 机械手最小角度限制 (°)
    float maxAngle = 45;             // 机械手最大角度限制 (°)
};

/**
 * @class DummyRobot
 * @brief 6自由度机械臂主控制类
 * 负责机械臂运动学解算、关节控制、轨迹规划、通信协议、状态管理
 */
class DummyRobot
{
public:
    /**
     * @brief 构造函数
     * @param _hcan CAN总线句柄
     */
    explicit DummyRobot(SocketCan* _hcan);
    
    /**
     * @brief 析构函数
     * 释放电机、机械手、运动学解算器等资源
     */
    ~DummyRobot();

    /**
     * @enum CommandMode
     * @brief 机械臂指令模式枚举
     */
    enum CommandMode
    {
        COMMAND_TARGET_POINT_SEQUENTIAL = 1,    // 顺序执行目标点（阻塞直到完成）
        COMMAND_TARGET_POINT_INTERRUPTABLE,     // 可中断目标点（新指令覆盖旧指令）
        COMMAND_CONTINUES_TRAJECTORY,           // 连续轨迹模式（高加速度、低速度）
    };

    // 机械臂默认参数定义
    const DOF6Kinematic::Joint6D_t REST_POSE = {0, 0, 0, 0, 0, 0}; // 上电默认姿态（关节角度）
    const float DEFAULT_JOINT_SPEED = 30;                            // 默认关节速度 (°/s)
    const DOF6Kinematic::Joint6D_t DEFAULT_JOINT_ACCELERATION_BASES = {150, 100, 200, 200, 200, 200}; // 关节加速度基准值
    const float DEFAULT_JOINT_ACCELERATION_LOW = 30;                 // 低加速度档位 (0~100缩放系数)
    const float DEFAULT_JOINT_ACCELERATION_HIGH = 100;               // 高加速度档位 (0~100缩放系数)
    const CommandMode DEFAULT_COMMAND_MODE = COMMAND_TARGET_POINT_INTERRUPTABLE; // 默认指令模式

    // 机械臂运行时状态
    DOF6Kinematic::Joint6D_t currentJoints = REST_POSE; // 当前关节角度
    DOF6Kinematic::Joint6D_t targetJoints = REST_POSE;  // 目标关节角度
    DOF6Kinematic::Joint6D_t initPose = REST_POSE;      // 初始化姿态（校准基准）
    DOF6Kinematic::Pose6D_t currentPose6D = {};         // 当前末端位姿（X/Y/Z/A/B/C）
    volatile uint8_t jointsStateFlag = 0b00000000;      // 关节运动状态标志（bit1~bit6对应关节1~6，1=运动完成）
    CommandMode commandMode = DEFAULT_COMMAND_MODE;     // 当前指令模式
    CtrlStepMotor* motorJ[7] = {nullptr};               // 关节电机控制器数组（索引0=所有关节，1~6=对应关节）
    DummyHand* hand = {nullptr};                        // 机械手控制器实例

    /**
     * @brief 机械臂初始化
     * 设置默认指令模式、默认关节速度
     */
    void Init();

    /**
     * @brief 关节空间运动指令（直接设置6个关节角度）
     * @param _j1~_j6 关节1~6的目标角度 (°)
     * @return true=角度合法（在限位范围内），false=角度超限
     */
    bool MoveJ(float _j1, float _j2, float _j3, float _j4, float _j5, float _j6);

    /**
     * @brief 笛卡尔空间运动指令（设置末端位姿）
     * @param _x/_y/_z 末端位置 (mm)
     * @param _a/_b/_c 末端姿态 (°)
     * @return true=逆解有有效解且角度合法，false=无解或角度超限
     */
    bool MoveL(float _x, float _y, float _z, float _a, float _b, float _c);

    /**
     * @brief 驱动关节运动到目标角度（带速度限制）
     * @param _joints 目标关节角度
     */
    void MoveJoints(DOF6Kinematic::Joint6D_t _joints);

    /**
     * @brief 设置关节运动速度
     * @param _speed 速度百分比 (0~100)，实际速度 = _speed * jointSpeedRatio
     */
    void SetJointSpeed(float _speed);

    /**
     * @brief 设置关节加速度
     * @param _acc 加速度百分比 (0~100)，实际加速度 = _acc/100 * 对应关节基准加速度
     */
    void SetJointAcceleration(float _acc);

    /**
     * @brief 更新所有关节角度（调用电机控制器的角度更新）
     */
    void UpdateJointAngles();

    /**
     * @brief 关节角度更新回调函数
     * 读取电机当前角度，更新currentJoints和jointsStateFlag
     */
    void UpdateJointAnglesCallback();

    /**
     * @brief 更新末端笛卡尔位姿
     * 通过正运动学解算currentJoints得到currentPose6D
     */
    void UpdateJointPose6D();

    /**
     * @brief 机械臂重启
     * 先重启所有关节电机，再复位系统
     */
    void Reboot();

    /**
     * @brief 设置机械臂使能状态
     * @param _enable true=使能所有关节电机，false=禁用
     */
    void SetEnable(bool _enable);

    /**
     * @brief 校准零点偏移
     * 手动移动到L姿态→首次校准→移动到休息姿态→二次校准→重启
     */
    void CalibrateHomeOffset();

    /**
     * @brief 回零操作
     * 以低速移动到零位姿态 {0,0,90,0,0,0}
     */
    void Homing();

    /**
     * @brief 回到休息姿态
     * 以低速移动到REST_POSE
     */
    void Resting();

    /**
     * @brief 判断机械臂是否正在运动
     * @return true=运动中，false=所有关节已到位
     */
    bool IsMoving();

    /**
     * @brief 判断机械臂是否使能
     * @return true=已使能，false=未使能
     */
    bool IsEnabled();

    /**
     * @brief 设置指令模式
     * @param _mode 指令模式（COMMAND_MODE枚举值）
     * 不同模式对应不同的速度/加速度配置
     */
    void SetCommandMode(uint32_t _mode);

private:
    SocketCan* hcan;                          // CAN总线句柄
    float jointSpeed = DEFAULT_JOINT_SPEED;           // 关节基础速度 (°/s)
    float jointSpeedRatio = 1;                        // 速度缩放系数（不同模式下不同）
    DOF6Kinematic::Joint6D_t dynamicJointSpeeds = {1, 1, 1, 1, 1, 1}; // 各关节动态速度
    DOF6Kinematic* dof6Solver;                        // 6自由度运动学解算器实例
    bool isEnabled = false;                           // 机械臂使能状态
};

#endif //REF_STM32F4_FW_DUMMY_ROBOT_H
